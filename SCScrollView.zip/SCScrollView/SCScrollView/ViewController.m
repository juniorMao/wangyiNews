//
//  ViewController.m
//  SCScrollView
//
//  Created by 毛强 on 2016/12/1.
//  Copyright © 2016年 maoqiang. All rights reserved.
//

#import "ViewController.h"
#import "SCScrollViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSArray *buttonTitles = @[@"title1", @"title2", @"title3", @"title4", @"title5"];
    UIView *view1 = [[UIView alloc]init];
    view1.backgroundColor = [UIColor redColor];
    
    UIView *view2 = [[UIView alloc]init];
    view2.backgroundColor = [UIColor greenColor];
    
    UIView *view3 = [[UIView alloc]init];
    view3.backgroundColor = [UIColor blueColor];
    
    UIView *view4 = [[UIView alloc]init];
    view4.backgroundColor = [UIColor purpleColor];
    
    UIView *view5 = [[UIView alloc]init];
    view5.backgroundColor = [UIColor whiteColor];
    
    NSArray *Views = @[view1, view2, view3, view4,view5];
    
    SCScrollViewController*vc = [SCScrollViewController ScrollViewControllerWithViews:Views buttonsTitle:buttonTitles];
    
    vc.chooseButtonWidth = SCREENWIDTH / 4;
//    vc.chooseButtonHeight = 60;
    [vc refreshVC];
    [self.navigationController pushViewController:vc animated:YES];
}

- (UIView*)duplicate:(UIView*)view
{
    NSData * tempArchive = [NSKeyedArchiver archivedDataWithRootObject:view];
    return [NSKeyedUnarchiver unarchiveObjectWithData:tempArchive];
}

@end
